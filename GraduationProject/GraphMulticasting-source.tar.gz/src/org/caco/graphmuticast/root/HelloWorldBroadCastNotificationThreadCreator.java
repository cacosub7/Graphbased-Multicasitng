package org.caco.graphmuticast.root;

import org.caco.graphmuticast.message.HelloWorldBroadCastNotificaiton;
import org.greatfree.concurrency.interactive.NotificationThreadCreatable;

public class HelloWorldBroadCastNotificationThreadCreator implements NotificationThreadCreatable<HelloWorldBroadCastNotificaiton,HelloWorldBroadCastNotificationThread>{

	@Override
	public HelloWorldBroadCastNotificationThread createNotificationThreadInstance(int taskSize) {
		return new HelloWorldBroadCastNotificationThread(taskSize);
	}



}
