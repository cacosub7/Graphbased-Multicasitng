package org.caco.graphmuticast.root;
//CREATED BY CACO 4.25

import java.io.IOException;

import org.greatfree.chat.ChatConfig;
import org.greatfree.data.ServerConfig;
import org.greatfree.dip.multicast.MulticastConfig;
import org.greatfree.dip.p2p.RegistryConfig;
import org.greatfree.exceptions.DistributedNodeFailedException;
import org.greatfree.exceptions.RemoteReadException;
import org.greatfree.server.Peer;
import org.greatfree.util.TerminateSignal;

public class RootPEER {
	private Peer<RootPEERDispatcher> peer;
	public RootPEER() {
	}

	private static RootPEER instance = new RootPEER();

	public static RootPEER ROOT() {
		if (instance == null) {
			instance = new RootPEER();
			return instance;
		} else {
			return instance;
		}
	}

	public void stop(long timeout)
			throws ClassNotFoundException, IOException, InterruptedException, RemoteReadException {
		this.peer.stop(timeout);
		RootGraphMulticastor.ROOT().stop();
		TerminateSignal.SIGNAL().setTerminated();
	}

	public void start() throws IOException, ClassNotFoundException, RemoteReadException, InstantiationException,
			IllegalAccessException, InterruptedException, DistributedNodeFailedException {
		this.peer = new Peer.PeerBuilder<RootPEERDispatcher>().peerPort(ChatConfig.CHAT_SERVER_PORT)
				.peerName(MulticastConfig.CLUSTER_SERVER_ROOT_NAME)
				.registryServerIP(RegistryConfig.PEER_REGISTRY_ADDRESS)
				.registryServerPort(RegistryConfig.PEER_REGISTRY_PORT).isRegistryNeeded(true)
				.listenerCount(ServerConfig.LISTENING_THREAD_COUNT)
				.dispatcher(new RootPEERDispatcher(RegistryConfig.DISPATCHER_THREAD_POOL_SIZE,
						RegistryConfig.DISPATCHER_THREAD_POOL_KEEP_ALIVE_TIME,
						RegistryConfig.SCHEDULER_THREAD_POOL_SIZE,
						RegistryConfig.SCHEDULER_THREAD_POOL_KEEP_ALIVE_TIME))
				.freeClientPoolSize(RegistryConfig.CLIENT_POOL_SIZE).readerClientSize(RegistryConfig.READER_CLIENT_SIZE)
				.syncEventerIdleCheckDelay(RegistryConfig.SYNC_EVENTER_IDLE_CHECK_DELAY)
				.syncEventerIdleCheckPeriod(RegistryConfig.SYNC_EVENTER_IDLE_CHECK_PERIOD)
				.syncEventerMaxIdleTime(RegistryConfig.SYNC_EVENTER_MAX_IDLE_TIME)
				.asyncEventQueueSize(RegistryConfig.ASYNC_EVENT_QUEUE_SIZE)
				.asyncEventerSize(RegistryConfig.ASYNC_EVENTER_SIZE)
				.asyncEventingWaitTime(RegistryConfig.ASYNC_EVENTING_WAIT_TIME)
				.asyncEventerWaitTime(RegistryConfig.ASYNC_EVENTER_WAIT_TIME)
				.asyncEventerWaitRound(RegistryConfig.ASYNC_EVENTER_WAIT_ROUND)
				.asyncEventIdleCheckDelay(RegistryConfig.ASYNC_EVENT_IDLE_CHECK_DELAY)
				.asyncEventIdleCheckPeriod(RegistryConfig.ASYNC_EVENT_IDLE_CHECK_PERIOD)
				.schedulerPoolSize(RegistryConfig.SCHEDULER_THREAD_POOL_SIZE)
				.schedulerKeepAliveTime(RegistryConfig.SCHEDULER_THREAD_POOL_KEEP_ALIVE_TIME).build();

		this.peer.start();
		RootGraphMulticastor.ROOT().start(this.peer.getClientPool());
	}



	
}
