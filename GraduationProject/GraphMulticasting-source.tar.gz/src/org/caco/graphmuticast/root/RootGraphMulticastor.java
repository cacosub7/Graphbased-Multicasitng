package org.caco.graphmuticast.root;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.caco.graphmuticast.message.MST;
import org.caco.graphmuticast.message.MSTtools;
import org.caco.graphmuticast.message.PostMSTNotification;
import org.greatfree.chat.ChatConfig;
import org.greatfree.client.FreeClientPool;
import org.greatfree.client.IPPort;
import org.greatfree.client.RemoteReader;
import org.greatfree.client.SyncRemoteEventer;
import org.greatfree.concurrency.Scheduler;
import org.greatfree.dip.multicast.MulticastConfig;
import org.greatfree.dip.multicast.message.PeerAddressRequest;
import org.greatfree.dip.multicast.message.PeerAddressResponse;
import org.greatfree.dip.p2p.RegistryConfig;
import org.greatfree.exceptions.RemoteReadException;
import org.greatfree.message.ServerMessage;
import org.greatfree.message.multicast.ClusterNameRequest;
import org.greatfree.message.multicast.ClusterNameResponse;
import org.greatfree.util.NodeID;
import org.greatfree.util.Tools;

public class RootGraphMulticastor {
	private MST mstree;
	private String rootName;
	private List<IPPort> childIpPorts;
//This field is used to detect if the childs got the MST.Caco 
	private boolean isChildsReady;
	private SyncRemoteEventer<ServerMessage> eventer;

	private RootGraphMulticastor() {
	}

	private static RootGraphMulticastor instance = new RootGraphMulticastor();

	public static RootGraphMulticastor ROOT() {
		if (instance == null) {
			instance = new RootGraphMulticastor();
			return instance;
		} else {
			return instance;
		}
	}

	public void start(FreeClientPool clientPool)
			throws ClassNotFoundException, RemoteReadException, IOException, InterruptedException {
		this.isChildsReady = false;
		this.eventer = new SyncRemoteEventer<ServerMessage>(clientPool);
		this.rootName = MulticastConfig.CLUSTER_SERVER_ROOT_NAME;
// Get child's name from register server,then construct a Graph who will be converted  to MST .Caco
		String[] chilsnameStrings = GetChildsName();
		if (chilsnameStrings != null) {
			this.mstree = MSTtools.constructMST(chilsnameStrings);
			MSTtools.printRootTree(mstree.getMSTtree());
			MSTtools.PrintMatrix(mstree.getMatrix());
// notify the mst to the CSserver.Caco
			this.eventer.notify(ChatConfig.CHAT_SERVER_ADDRESS, ChatConfig.MST_SERVER_PORT,
					new PostMSTNotification(this.mstree));
//get Childs IPport.Caco
			getchildIpPorts();
//Checking childs state
			isChildsReadyChecking();
		}
	}

	public String[] GetChildsName() throws ClassNotFoundException, RemoteReadException, IOException {
		ClusterNameResponse nameResponse = (ClusterNameResponse) read(RegistryConfig.PEER_REGISTRY_ADDRESS,
				RegistryConfig.PEER_REGISTRY_PORT, new ClusterNameRequest());
		if (nameResponse.getPeersName() != null) {
			System.out.println("--------------------------------------------");
			System.out.println("RootPeer-nameResponse: name size = " + nameResponse.getPeersName().size());
			List<String> childsNameList = new ArrayList<String>();
			for (String name : nameResponse.getPeersName().values()) {
				System.out.println(" Childs name = " + name);
				childsNameList.add(name);
			}
//the reason why we add the Root to the head of childname-list is that it will be at the top of the MST,which ensures  the order of notification forwarding in the Multicasting.Caco 
			childsNameList.add(0, rootName);
			String[] strings = new String[childsNameList.size()];
			System.out.println("Vertex array :");
			childsNameList.toArray(strings);
			System.out.println("--------------------------------------------");
			System.out.println(Arrays.toString(strings));
			return strings;
		}
		System.out.println("NULL,Can't get ChilsName from reg server!!");
		return null;
	}

	public void getchildIpPorts() throws ClassNotFoundException, RemoteReadException, IOException {
		this.childIpPorts = new ArrayList<IPPort>();
		IPPort childIP;
		if (this.mstree.getMSTtree().get(rootName) != null) {
			System.out.println("\n--------------------------------------------");
			System.out.println("Current PeerName: " + this.rootName);
			System.out.println("--------------------------------------------");
			System.out.println("Its childs IP&Ports:");
			for (String childName : this.mstree.getMSTtree().get(this.rootName)) {
				PeerAddressResponse response = (PeerAddressResponse) this.read(RegistryConfig.PEER_REGISTRY_ADDRESS,
						RegistryConfig.PEER_REGISTRY_PORT, new PeerAddressRequest(Tools.getHash(childName)));
				childIP = new IPPort(response.getPeerAddress());
				this.childIpPorts.add(childIP);
				System.out.println(childName + " " + childIP);
			}
			System.out.println("\n--------------------------------------------");
			System.out.println("Child's IPPorts have been stored");
		} else {
			System.out.println("\n--------------------------------------------");
			System.out.println("There have No child from MST to send , childIPorts build faild");
		}
	}

	public void broadCastNotify(ServerMessage notification)
			throws ClassNotFoundException, RemoteReadException, IOException, InterruptedException {
		if (this.isChildsReady) {
			if (this.mstree != null) {
				if (this.childIpPorts != null) {
					for (IPPort childiPort : this.childIpPorts) {
						this.eventer.notify(childiPort, notification);
					}
				} else {
					System.out.println("There have no child , Multicast END.");
				}
			} else {
				System.out.println("MST has not build up");
			}
		} else {
			System.out.println("Child are not ready!");
		}
	}

	public boolean isChildsReady() {
		return isChildsReady;
	}

	public void setChildsReady(boolean isChildsReady) {
		this.isChildsReady = isChildsReady;
	}

	public void isChildsReadyChecking() {
		Scheduler.GREATFREE().init(RegistryConfig.SCHEDULER_THREAD_POOL_SIZE,
				RegistryConfig.SCHEDULER_THREAD_POOL_KEEP_ALIVE_TIME);
		Scheduler.GREATFREE().submit(new IsChildsReadyChecker(), ChatConfig.CHAT_POLLING_DELAY,
				ChatConfig.ROOT_POLLING_PERIOD);
	}

	public ServerMessage read(String ip, int port, ServerMessage request)
			throws ClassNotFoundException, RemoteReadException, IOException {
		return RemoteReader.REMOTE().read(NodeID.DISTRIBUTED().getKey(), ip, port, request);
	}

	public void stop() throws IOException, InterruptedException {
		this.eventer.dispose();
	}
}
