package org.caco.graphmuticast.root;

import org.caco.graphmuticast.message.ShutdownClusterNotification;
import org.greatfree.concurrency.interactive.NotificationThreadCreatable;

public class ShutdownClusterNotificationThreadCreator implements NotificationThreadCreatable<ShutdownClusterNotification,ShutdownClusterNotificationThread>{

	@Override
	public ShutdownClusterNotificationThread createNotificationThreadInstance(int taskSize) {
		return new ShutdownClusterNotificationThread(taskSize);
	}

}
