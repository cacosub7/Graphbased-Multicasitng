package org.caco.graphmuticast.root;

//Created by Caco.   5.15
import java.io.IOException;

import org.caco.graphmuticast.message.ChildsStateRequest;
import org.caco.graphmuticast.message.ChildsStateResponse;
import org.greatfree.chat.ChatConfig;
import org.greatfree.concurrency.Scheduler;
import org.greatfree.dip.p2p.RegistryConfig;
import org.greatfree.exceptions.RemoteReadException;

public class IsChildsReadyChecker implements Runnable {

	@Override
	public void run() {
		try {
			ChildsStateResponse response = (ChildsStateResponse) RootGraphMulticastor.ROOT()
					.read(ChatConfig.CHAT_SERVER_ADDRESS, ChatConfig.MST_SERVER_PORT, new ChildsStateRequest());
			if (response.isChildReady()) {
				RootGraphMulticastor.ROOT().setChildsReady(true);
				System.out.println("=============================================");
				System.out.println("Polling Res:");
				System.out.println("All childs have gotten the MST,Multicast is all set!!");
				System.out.println("=============================================");
				Scheduler.GREATFREE().shutdown(RegistryConfig.SCHEDULER_SHUTDOWN_TIMEOUT);
			} else {
				System.out.println("---------------------------------------------------------------------");
				System.out.println("Polling Res:");
				System.out.println("Wait for all child nodes to get MST ");
				System.out.println("---------------------------------------------------------------------");
			}
		} catch (ClassNotFoundException | RemoteReadException | IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			System.out.println("=====Scheduler thread  SHUTDOWN , Polling over=====");
			// e.printStackTrace();
		}
	}

}
