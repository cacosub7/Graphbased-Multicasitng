package org.caco.graphmuticast.root;

import java.io.IOException;

import org.greatfree.data.ServerConfig;
import org.greatfree.exceptions.DistributedNodeFailedException;
import org.greatfree.exceptions.RemoteReadException;
import org.greatfree.util.TerminateSignal;

public class StartRoot {
	public static void main(String[] args)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, IOException,
			RemoteReadException, InterruptedException, DistributedNodeFailedException {
		System.out.println("Root starting up ...");
		RootPEER.ROOT().start();
		System.out.println("Root started ...");

		while (!TerminateSignal.SIGNAL().isTerminated()) {
			try {
				Thread.sleep(ServerConfig.TERMINATE_SLEEP);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
