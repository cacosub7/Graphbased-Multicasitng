package org.caco.graphmuticast.root;

import java.io.IOException;

import org.caco.graphmuticast.message.HelloWorldBroadCastNotificaiton;
import org.greatfree.concurrency.interactive.NotificationQueue;
import org.greatfree.data.ServerConfig;
import org.greatfree.exceptions.RemoteReadException;

public class HelloWorldBroadCastNotificationThread extends NotificationQueue<HelloWorldBroadCastNotificaiton>{


	public HelloWorldBroadCastNotificationThread(int taskSize) {
		super(taskSize);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		HelloWorldBroadCastNotificaiton notification;
		while (!this.isShutdown())
		{
			while (!this.isEmpty())
			{
				try
				{
					notification = this.getNotification();
					RootGraphMulticastor.ROOT().broadCastNotify(notification);
					this.disposeMessage(notification);
				}
				catch (InterruptedException | IOException e)
				{
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (RemoteReadException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			try
			{
				// Wait for a moment after all of the existing notifications are processed. 01/20/2016, Bing Li
				this.holdOn(ServerConfig.NOTIFICATION_THREAD_WAIT_TIME);
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}	
	}

}
