package org.caco.graphmuticast.root;
//Created by Caco,5.20
import java.io.IOException;

import org.caco.graphmuticast.message.ShutdownClusterNotification;
import org.greatfree.concurrency.interactive.NotificationQueue;
import org.greatfree.data.ServerConfig;
import org.greatfree.exceptions.RemoteReadException;
import org.greatfree.util.ServerStatus;

public class ShutdownClusterNotificationThread extends NotificationQueue<ShutdownClusterNotification> {

	public ShutdownClusterNotificationThread(int taskSize) {
		super(taskSize);
	}

	@Override
	public void run() {
		ShutdownClusterNotification notification;
		while (!this.isShutdown()) {
			while (!this.isEmpty()) {
				try {
					notification = this.getNotification();
					RootGraphMulticastor.ROOT().broadCastNotify(notification);
					ServerStatus.FREE().setShutdown();
					RootPEER.ROOT().stop(ServerConfig.SERVER_SHUTDOWN_TIMEOUT);
					this.disposeMessage(notification);
				} catch (InterruptedException | ClassNotFoundException | IOException | RemoteReadException e) {
					e.printStackTrace();
				}
			}
			try {
				// Wait for a moment after all of the existing notifications are processed.
				this.holdOn(ServerConfig.NOTIFICATION_THREAD_WAIT_TIME);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
