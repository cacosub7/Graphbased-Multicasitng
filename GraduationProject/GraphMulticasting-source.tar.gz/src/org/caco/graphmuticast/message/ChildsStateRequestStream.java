package org.caco.graphmuticast.message;
//CREATED BY CACO
import java.io.ObjectOutputStream;
import java.util.concurrent.locks.Lock;

import org.greatfree.client.OutMessageStream;

public class ChildsStateRequestStream  extends OutMessageStream<ChildsStateRequest>{

	public ChildsStateRequestStream(ObjectOutputStream out, Lock lock, ChildsStateRequest message) {
		super(out, lock, message);
	}

}
