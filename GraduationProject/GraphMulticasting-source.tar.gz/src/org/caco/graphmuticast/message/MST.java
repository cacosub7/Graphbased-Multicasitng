package org.caco.graphmuticast.message;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class MST implements Serializable {

	private static final long serialVersionUID = -9158387399247028403L;
	private Map<String, List<String>> MSTtree;
	private int[][] matrix;// 顶点矩阵

	public MST(Map<String, List<String>> mSTtree, int[][] matrix) {
		super();
		this.MSTtree = mSTtree;
		this.matrix = matrix;
	}

	public Map<String, List<String>> getMSTtree() {
		return MSTtree;
	}
//only Tree constructor,used in the situation that sending to the childs,Caco
	public MST(Map<String, List<String>> mSTtree) {
		super();
		this.MSTtree = mSTtree;
	}
	public void setMSTtree(Map<String, List<String>> mSTtree) {
		MSTtree = mSTtree;
	}

	public int[][] getMatrix() {
		return matrix;
	}

	public void setMatrix(int[][] matrix) {
		this.matrix = matrix;
	}

	public int GetNodeCount() {
		return matrix.length;
	}
}
