package org.caco.graphmuticast.message;
//Created by caco 4.25

import java.io.ObjectOutputStream;
import java.util.concurrent.locks.Lock;

import org.greatfree.client.OutMessageStream;

public class MSTTreeRequestStream extends OutMessageStream<MSTTreeRequest>{

	public MSTTreeRequestStream(ObjectOutputStream out, Lock lock, MSTTreeRequest message) {
		super(out, lock, message);
	}

}
