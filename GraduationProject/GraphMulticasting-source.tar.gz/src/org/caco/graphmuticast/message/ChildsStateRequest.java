package org.caco.graphmuticast.message;

import org.greatfree.message.ServerMessage;

public class ChildsStateRequest extends ServerMessage{
//Created by Caco
	private static final long serialVersionUID = -2622349057320959358L;

	public ChildsStateRequest() {
		super(MuticastMessageType.CHILDS_STATE_REQUEST);
	}

}
