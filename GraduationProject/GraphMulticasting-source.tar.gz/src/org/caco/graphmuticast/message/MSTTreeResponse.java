package org.caco.graphmuticast.message;

import org.greatfree.message.ServerMessage;

public class MSTTreeResponse extends ServerMessage{

	private static final long serialVersionUID = 3930594700263079064L;

	private boolean isRecived;
	private MST MSTtree;

	public MSTTreeResponse( MST mSTtree) {
		super(MuticastMessageType.MSTTREE_RESPONSE);
		MSTtree = mSTtree;
		isRecived = true;
	}
	public boolean isRecived() {
		return isRecived;
	}
	public void setRecived(boolean isRecived) {
		this.isRecived = isRecived;
	}
	public MSTTreeResponse(boolean isRecived)
	{
		super(MuticastMessageType.MSTTREE_RESPONSE);
		this.isRecived = isRecived;
	} 
	public MST getMSTtree() {
		return MSTtree;
	}

	public void setMSTtree(MST mSTtree) {
		MSTtree = mSTtree;
	} 

	
}
