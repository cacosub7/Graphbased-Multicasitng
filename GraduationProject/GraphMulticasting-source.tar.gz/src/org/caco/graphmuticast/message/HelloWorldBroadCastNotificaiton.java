package org.caco.graphmuticast.message;

import org.greatfree.dip.multicast.HelloWorld;
import org.greatfree.message.ServerMessage;

public class HelloWorldBroadCastNotificaiton extends ServerMessage{

	private HelloWorld hl;
	private static final long serialVersionUID = 8402526609557609463L;

	public HelloWorldBroadCastNotificaiton(HelloWorld hl) {
		super(MuticastMessageType.HW_NOTIFICATION);
		this.hl = hl;
			}
	public HelloWorld getHelloWorld()
	{
		return this.hl;
	}
	
}
