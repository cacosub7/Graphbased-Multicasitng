package org.caco.graphmuticast.message;

import org.greatfree.message.ServerMessage;

//Created by caco 4.25
public class MSTTreeRequest extends ServerMessage {

	private static final long serialVersionUID = -4435020528771588761L;
	private String childName;
	public MSTTreeRequest(String childName) {
		super(MuticastMessageType.MSTTREE_REQUEST);
		this.childName = childName;
	}
	public String getChildName() {
		return childName;
	}
	public void setChildName(String childName) {
		this.childName = childName;
	}

}
