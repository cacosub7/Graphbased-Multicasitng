package org.caco.graphmuticast.message;

import org.greatfree.message.ServerMessage;

public class ShutdownMSTserverNotification extends ServerMessage {

	/**
	 *The notification aims to notify the MSTserver to shutdown , Caco 
	 */
	private static final long serialVersionUID = 6922317730009273212L;

	public ShutdownMSTserverNotification() {
		super(MuticastMessageType.SHUTDOWN_MSTSERVER_NOTIFICATION);
	}

}
