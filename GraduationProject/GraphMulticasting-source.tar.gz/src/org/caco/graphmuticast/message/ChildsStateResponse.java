package org.caco.graphmuticast.message;

import org.greatfree.message.ServerMessage;

public class ChildsStateResponse extends ServerMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5581716006885782634L;
	private boolean isChildReady;
	public ChildsStateResponse(boolean isChildsReady) {
		super(MuticastMessageType.CHILDS_STATE_RESPONSE);
		this.isChildReady = isChildsReady;
	}
	public boolean isChildReady() {
		return isChildReady;
	}
	public void setChildReady(boolean isChildReady) {
		this.isChildReady = isChildReady;
	}

}
