package org.caco.graphmuticast.message;

import org.greatfree.message.ServerMessage;

//CREATED BY CACO 4.25
public class PostMSTNotification extends ServerMessage {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7078695699959918187L;
	private MST mST;
	public PostMSTNotification(MST mstree) {
		super(MuticastMessageType.POSTMST_NOTIFICATION);
		this.mST = mstree;
	}
	public MST getmST() {
		return mST;
	}
	public void setmST(MST mST) {
		this.mST = mST;
	}

}
