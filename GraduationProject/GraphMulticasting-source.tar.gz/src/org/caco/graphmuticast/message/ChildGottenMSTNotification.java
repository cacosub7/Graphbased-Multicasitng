package org.caco.graphmuticast.message;

import org.greatfree.message.ServerMessage;
//Created by Caco 5.15
public class ChildGottenMSTNotification extends ServerMessage{


	private static final long serialVersionUID = 6306059027324520749L;
	private String childname;
	public ChildGottenMSTNotification(String childname) {
		super(MuticastMessageType.CHILD_GOTTEN_MST_NOTIFIATION);
		this.childname = childname;
	}
	public String getChildname() {
		return childname;
	}
	public void setChildname(String childname) {
		this.childname = childname;
	}

}
