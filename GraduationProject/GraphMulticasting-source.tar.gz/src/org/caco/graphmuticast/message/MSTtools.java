package org.caco.graphmuticast.message;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.greatfree.dip.multicast.MulticastConfig;

public class MSTtools {
	private final static int MAX_WEIGHT = 1000;
	private final static int MAX_ACTIVE_WEIGH = 100;

	public static MST constructMST(String[] vertexs) {
		System.out.println("Start constructing the MST(Minimum spanning tree)");
		Map<String, List<String>> mst = new HashMap<String, List<String>>();
		int vertexSize = vertexs.length;
//Adjacency matrix of the storage structure of the graph。Caco
		int[][] matrix = createRadomConnectedGraph(vertexSize);
		int[] lowcost = new int[vertexSize];// this array is used to find the minimum weight of node in matrix,caco
		int[] adjvex = new int[vertexSize];// this array is used to record the index of parent node , who belongs to
											// MST,in vertex.caco.
		String parentNode;
		String childNode;
		int min, minId, sum = 0;
		for (int i = 1; i < vertexSize; i++) {
			lowcost[i] = matrix[0][i];
		}
		for (int i = 1; i < vertexSize; i++) {
			min = MAX_WEIGHT;
			minId = 0;
			for (int j = 1; j < vertexSize; j++) {
				if (lowcost[j] < min && lowcost[j] > 0) {
					min = lowcost[j];
					minId = j;
				}
			}
//
			parentNode = vertexs[adjvex[minId]];
			childNode = vertexs[minId];
			if (!mst.containsKey(parentNode))
//add current node to the map,caco
			{
				mst.put(parentNode, new LinkedList<String>());
				mst.get(parentNode).add(childNode);
			} else {
				mst.get(parentNode).add(childNode);
			}
			System.out.println("Node：" + parentNode + "add child " + childNode + " min weight：" + min);
			sum += min;
			lowcost[minId] = 0;
			for (int j = 1; j < vertexSize; j++) {
				if (lowcost[j] != 0 && matrix[minId][j] < lowcost[j]) {
					lowcost[j] = matrix[minId][j];
//record the parent node Index who has been(or will be) added to the MST,caco
					adjvex[j] = minId;
				}
			}
		}
		System.out.println("Shortest Path Value:" + sum);
		return new MST(mst, matrix);

	}

	public static int[][] createRadomConnectedGraph(int vertex) {
//		matrix[0] = new int[] { 0, 10, MAX_WEIGHT, MAX_WEIGHT, MAX_WEIGHT, 11, MAX_WEIGHT, MAX_WEIGHT, MAX_WEIGHT };
//
//		matrix[1] = new int[] { 10, 0, 18, MAX_WEIGHT, MAX_WEIGHT, MAX_WEIGHT, 16, MAX_WEIGHT, 12 };
//
//		matrix[2] = new int[] { MAX_WEIGHT, MAX_WEIGHT, 0, 22, MAX_WEIGHT, MAX_WEIGHT, MAX_WEIGHT, MAX_WEIGHT, 8 };
//
//		matrix[3] = new int[] { MAX_WEIGHT, MAX_WEIGHT, 22, 0, 20, MAX_WEIGHT, MAX_WEIGHT, 16, 21 };
//
//		matrix[4] = new int[] { MAX_WEIGHT, MAX_WEIGHT, MAX_WEIGHT, 20, 0, 26, MAX_WEIGHT, 7, MAX_WEIGHT };
//
//		matrix[5] = new int[] { 11, MAX_WEIGHT, MAX_WEIGHT, MAX_WEIGHT, 26, 0, 17, MAX_WEIGHT, MAX_WEIGHT };
//
//		matrix[6] = new int[] { MAX_WEIGHT, 16, MAX_WEIGHT, MAX_WEIGHT, MAX_WEIGHT, 17, 0, 19, MAX_WEIGHT };
//
//		matrix[7] = new int[] { MAX_WEIGHT, MAX_WEIGHT, MAX_WEIGHT, 16, 7, MAX_WEIGHT, 19, 0, MAX_WEIGHT };
//
//		matrix[8] = new int[] { MAX_WEIGHT, 12, 8, 21, MAX_WEIGHT, MAX_WEIGHT, MAX_WEIGHT, MAX_WEIGHT, 0 };
		System.out.println("--------------------Random connected Graph generating------------------------");

		int[][] matrix = new int[vertex][vertex];
		Map<Integer, List<Integer>> containerMap;
		Random random = new Random();
		int edgeNumber;
		int weight = -1;
		Set<Integer> unconnectedNodes = new HashSet<Integer>();
		containerMap = new HashMap<Integer, List<Integer>>();
// Init matrix
		for (int i = 0; i < vertex; i++) {
			// Init unconnectedNodesSet, default all of them.
			unconnectedNodes.add(i);
			for (int j = 0; j < vertex; j++) {
				matrix[i][j] = MAX_WEIGHT;
			}
			matrix[i][i] = 0;
		}		
// Graph Deduction
		int edgeUpper = vertex * (vertex - 1) / 2;
		int edgelower = (vertex - 2) * (vertex - 1) / 2;
	
//generate the suitable edgenumber,caco
		edgeNumber = edgelower + random.nextInt(edgeUpper - edgelower);

		System.out.println("Random edges number: " + edgeNumber);

//Add edges.Caco

		for (int i = 0; i < edgeNumber; i++) {
			int from = random.nextInt(vertex);
			int to = random.nextInt(vertex);
			while (containerMap.containsKey(from)) {
				// Try to Search for a new connection if it exists already .Caco
				List<Integer> nodes = containerMap.get(from);
				if (nodes.contains(to)) {
					// restart the generation
					System.out.println("Same connection error: " + from + " -> " + to);
					from = random.nextInt(vertex);
					to = random.nextInt(vertex);
				} else {

					nodes.add(to);
					System.out.println(from + " -> " + to);
					break;
				}
			}
//Add a new one-way connection to Map if it not exists.Caco
			if (!containerMap.containsKey(from)) {
				containerMap.put(from, new ArrayList<Integer>());
				containerMap.get(from).add(to);
				System.out.println(from + " -> " + to);
			}

			weight = 1 + random.nextInt(MAX_ACTIVE_WEIGH);
//Avoid self-ring edges.Caco
			if (from != to) {

// Avoid the Parallel edges like "a->b" "b->a" from begin,Caco
				constructEqualSides(containerMap, to, from, weight, matrix);

				unconnectedNodes.remove(to);
				unconnectedNodes.remove(from);
			} else {
				//loop again
				i -= 1;
			}
		}
//default-tolerant that Coordinate the remaining unconnected vertices .Caco
		if (!unconnectedNodes.isEmpty()) {
			System.out.println("unconnected node :");
			for (int leftnode : unconnectedNodes) {
				System.out.println("number : " + leftnode);
				int randomnode = leftnode;
				while (randomnode == leftnode)
					randomnode = random.nextInt(vertex);
				System.out.println("add " + leftnode + "-> " + randomnode);
				weight = 1 + random.nextInt(MAX_ACTIVE_WEIGH);
				constructEqualSides(containerMap, randomnode, leftnode, weight, matrix);
			}
		}

		System.out.println("-------------------------Generating End-----------------------------");
		return matrix;
	}

	public static void constructEqualSides(Map<Integer, List<Integer>> containerMap, int to, int from, int weight,
			int[][] matrix) {
		if (containerMap.containsKey(to
				)) {
			List<Integer> nodes = containerMap.get(to);
			if (!nodes.contains(from)) {
				nodes.add(from);
			}
		} else {
			containerMap.put(to, new ArrayList<Integer>());
			containerMap.get(to).add(from);
		}
		matrix[to][from] = weight;
		matrix[from][to] = weight;
	}

	public static void printRootTree(Map<String, List<String>> MSTtree) {
		System.out.println("\n-------------------------------------------------------------------");
		System.out.println("Minimum spanning tree in this Muticast System:");
		for (Map.Entry<String, List<String>> entry : MSTtree.entrySet()) {
			if (!entry.getKey().equals(MulticastConfig.CLUSTER_CLIENT_ROOT_NAME)) {
				System.out.println("->Parent: " + entry.getKey());
			} else {
				System.out.println("->Parent: Root");
			}
			if (entry.getValue() != null) {
				for (String child : entry.getValue()) {
					System.out.println("\t\tChild: " + child);
				}
			} else {
				System.out.println("\t\tChild: NULL");
			}
		}
		System.out.println("-------------------------------------------------------------------");
	}

	public static void PrintMatrix(int[][] matrix) {
		System.out.println("--------------------------------------------");
		System.out.println("Matrix of the Graph");
		for (int i = 0; i < matrix.length; i++) {
			System.out.println(Arrays.toString(matrix[i]));
		}
	}
}
