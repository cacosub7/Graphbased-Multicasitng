package org.caco.graphmuticast.message;
//Created by Caco 5.20
import org.greatfree.message.ServerMessage;

public class ShutdownClusterNotification extends ServerMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2627758224693023252L;

	public ShutdownClusterNotification() {
		super(MuticastMessageType.SHUTDOWN_CLUSTER_NOTIFICATION);
	}

}
