package org.caco.graphmuticast.message;
//Created  by caco 4/25

public class MuticastMessageType {
	public final static int MSTTREE_REQUEST = 60001;
	public final static int MSTTREE_RESPONSE = 60002;
	public final static int POSTMST_NOTIFICATION = 60003;
	public final static int HW_NOTIFICATION = 60004;
	public final static int CHILDS_STATE_REQUEST = 60005;
	public final static int CHILDS_STATE_RESPONSE = 60006;
	public final static int CHILD_GOTTEN_MST_NOTIFIATION = 60007;
	public final static int SHUTDOWN_MSTSERVER_NOTIFICATION = 60008;
	public final static int SHUTDOWN_CLUSTER_NOTIFICATION = 60009;

}
