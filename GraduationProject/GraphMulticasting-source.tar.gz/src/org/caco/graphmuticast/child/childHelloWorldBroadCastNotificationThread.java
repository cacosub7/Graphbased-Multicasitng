package org.caco.graphmuticast.child;

import java.io.IOException;

import org.caco.graphmuticast.message.HelloWorldBroadCastNotificaiton;
import org.greatfree.concurrency.interactive.NotificationQueue;
import org.greatfree.data.ServerConfig;
import org.greatfree.exceptions.RemoteReadException;

public class childHelloWorldBroadCastNotificationThread extends NotificationQueue<HelloWorldBroadCastNotificaiton> {

	public childHelloWorldBroadCastNotificationThread(int taskSize) {
		super(taskSize);
	}

	@Override
	public void run() {
		HelloWorldBroadCastNotificaiton notification;
		while (!this.isShutdown()) {
			while (!this.isEmpty()) {
				try {
					notification = this.getNotification();
					childGraphMuticastor.CHILD().broadcastNotify(notification);
					System.out.println("===========================");
					System.out.println("Message content: " + notification.getHelloWorld().getHelloWorld());
					System.out.println("===========================");
					this.disposeMessage(notification);
				} catch (InterruptedException e) {
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				} catch (RemoteReadException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			try {
				this.holdOn(ServerConfig.NOTIFICATION_THREAD_WAIT_TIME);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
