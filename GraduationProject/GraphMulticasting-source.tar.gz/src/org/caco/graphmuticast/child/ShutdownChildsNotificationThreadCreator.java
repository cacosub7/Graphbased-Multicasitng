package org.caco.graphmuticast.child;

import org.caco.graphmuticast.message.ShutdownClusterNotification;
import org.greatfree.concurrency.interactive.NotificationThreadCreatable;

public class ShutdownChildsNotificationThreadCreator implements NotificationThreadCreatable<ShutdownClusterNotification,ShutdownChildsNotificationThread>{

	@Override
	public ShutdownChildsNotificationThread createNotificationThreadInstance(int taskSize) {
		return new ShutdownChildsNotificationThread(taskSize);
	}

}
