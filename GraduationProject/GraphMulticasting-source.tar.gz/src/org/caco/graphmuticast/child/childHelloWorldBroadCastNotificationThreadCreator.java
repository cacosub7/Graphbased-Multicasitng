package org.caco.graphmuticast.child;

import org.caco.graphmuticast.message.HelloWorldBroadCastNotificaiton;
import org.greatfree.concurrency.interactive.NotificationThreadCreatable;

public class childHelloWorldBroadCastNotificationThreadCreator implements NotificationThreadCreatable<HelloWorldBroadCastNotificaiton,childHelloWorldBroadCastNotificationThread>{

	@Override
	public childHelloWorldBroadCastNotificationThread createNotificationThreadInstance(int taskSize) {
		return new childHelloWorldBroadCastNotificationThread(taskSize);
	}

}
