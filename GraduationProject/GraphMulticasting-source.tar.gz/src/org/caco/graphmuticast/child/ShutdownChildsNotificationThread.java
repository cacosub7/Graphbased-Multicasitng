package org.caco.graphmuticast.child;

import java.io.IOException;

import org.caco.graphmuticast.message.ShutdownClusterNotification;
import org.greatfree.concurrency.interactive.NotificationQueue;
import org.greatfree.data.ServerConfig;
import org.greatfree.exceptions.RemoteReadException;
import org.greatfree.util.ServerStatus;

public class ShutdownChildsNotificationThread extends NotificationQueue<ShutdownClusterNotification>{

	public ShutdownChildsNotificationThread(int taskSize) {
		super(taskSize);
	}

	@Override
	public void run() {
		ShutdownClusterNotification notification;
		while (!this.isShutdown())
		{
			while (!this.isEmpty())
			{
				try
				{
					notification = this.getNotification();
					childGraphMuticastor.CHILD().broadcastNotify(notification);
					ServerStatus.FREE().setShutdown();
					childPEER.CHILD().stop(ServerConfig.SERVER_SHUTDOWN_TIMEOUT);
					this.disposeMessage(notification);
				}
				catch (InterruptedException | IOException | ClassNotFoundException | RemoteReadException e)
				{
					e.printStackTrace();
				}
				
			}
			try
			{
				// Wait for a moment after all of the existing notifications are processed. 11/26/2014, Bing Li
				this.holdOn(ServerConfig.NOTIFICATION_THREAD_WAIT_TIME);
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}
	

}
