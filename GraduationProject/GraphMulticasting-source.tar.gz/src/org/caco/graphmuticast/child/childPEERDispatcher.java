package org.caco.graphmuticast.child;

import java.util.Calendar;

import org.caco.graphmuticast.message.HelloWorldBroadCastNotificaiton;
import org.caco.graphmuticast.message.MuticastMessageType;
import org.caco.graphmuticast.message.ShutdownClusterNotification;
import org.greatfree.client.OutMessageStream;
import org.greatfree.concurrency.interactive.NotificationDispatcher;
import org.greatfree.data.ServerConfig;
import org.greatfree.message.ServerMessage;
import org.greatfree.server.ServerDispatcher;

public class childPEERDispatcher extends ServerDispatcher<ServerMessage> {

	private NotificationDispatcher<HelloWorldBroadCastNotificaiton, childHelloWorldBroadCastNotificationThread, childHelloWorldBroadCastNotificationThreadCreator> helloworldBroadCastNotificationDispatcher;
	private NotificationDispatcher<ShutdownClusterNotification, ShutdownChildsNotificationThread, ShutdownChildsNotificationThreadCreator> shutdowBroadcastNotificationDispatcher;

	public childPEERDispatcher(int serverThreadPoolSize, long serverThreadKeepAliveTime, int schedulerPoolSize,
			long schedulerKeepAliveTime) {
		super(serverThreadPoolSize, serverThreadKeepAliveTime, schedulerPoolSize, schedulerKeepAliveTime);
		this.helloworldBroadCastNotificationDispatcher = new NotificationDispatcher.NotificationDispatcherBuilder<HelloWorldBroadCastNotificaiton, childHelloWorldBroadCastNotificationThread, childHelloWorldBroadCastNotificationThreadCreator>()
				.poolSize(ServerConfig.NOTIFICATION_DISPATCHER_POOL_SIZE)
				.threadCreator(new childHelloWorldBroadCastNotificationThreadCreator())
				.notificationQueueSize(ServerConfig.NOTIFICATION_QUEUE_SIZE)
				.dispatcherWaitTime(ServerConfig.NOTIFICATION_DISPATCHER_WAIT_TIME)
				.waitRound(ServerConfig.NOTIFICATION_DISPATCHER_WAIT_ROUND)
				.idleCheckDelay(ServerConfig.NOTIFICATION_DISPATCHER_IDLE_CHECK_DELAY)
				.idleCheckPeriod(ServerConfig.NOTIFICATION_DISPATCHER_IDLE_CHECK_PERIOD).scheduler(super.getScheduler())
				.build();
		this.shutdowBroadcastNotificationDispatcher = new NotificationDispatcher.NotificationDispatcherBuilder<ShutdownClusterNotification, ShutdownChildsNotificationThread, ShutdownChildsNotificationThreadCreator>()
				.poolSize(ServerConfig.NOTIFICATION_DISPATCHER_POOL_SIZE)
				.threadCreator(new ShutdownChildsNotificationThreadCreator())
				.notificationQueueSize(ServerConfig.NOTIFICATION_QUEUE_SIZE)
				.dispatcherWaitTime(ServerConfig.NOTIFICATION_DISPATCHER_WAIT_TIME)
				.waitRound(ServerConfig.NOTIFICATION_DISPATCHER_WAIT_ROUND)
				.idleCheckDelay(ServerConfig.NOTIFICATION_DISPATCHER_IDLE_CHECK_DELAY)
				.idleCheckPeriod(ServerConfig.NOTIFICATION_DISPATCHER_IDLE_CHECK_PERIOD).scheduler(super.getScheduler())
				.build();
	}

	@Override
	public void dispose(long timeout) throws InterruptedException {
		this.helloworldBroadCastNotificationDispatcher.dispose();
		this.shutdowBroadcastNotificationDispatcher.dispose();
		super.shutdown(timeout);
		System.out.println("ChildDispatcher-dispose(): done! ...");

	}

	@Override
	public void process(OutMessageStream<ServerMessage> message) {
		switch (message.getMessage().getType()) {
		case MuticastMessageType.HW_NOTIFICATION:
			System.out.println("HelloWorld_Graph_BroadCast_Notification received @" + Calendar.getInstance().getTime());
			if (!this.helloworldBroadCastNotificationDispatcher.isReady()) {
				// Execute the notification dispatcher concurrently. 02/15/2016, Bing Li
				super.execute(this.helloworldBroadCastNotificationDispatcher);
			}
			// Enqueue the instance of HelloWorldBroadcastResponse into the dispatcher for
			// concurrent processing. 02/15/2016, Bing Li
			this.helloworldBroadCastNotificationDispatcher
					.enqueue((HelloWorldBroadCastNotificaiton) message.getMessage());
			break;

		case MuticastMessageType.SHUTDOWN_CLUSTER_NOTIFICATION:
			System.out.println("<" + childPEER.CHILD().getChildIP() + ":" + childPEER.CHILD().getChildPort()
					+ ": SHUTDOWN_CHILDS_BROADCAST_NOTIFICATION received @" + Calendar.getInstance().getTime());
			if (!this.shutdowBroadcastNotificationDispatcher.isReady()) {
				super.execute(this.shutdowBroadcastNotificationDispatcher);
			}
			this.shutdowBroadcastNotificationDispatcher.enqueue((ShutdownClusterNotification) message.getMessage());
			break;
		}
	}
}
