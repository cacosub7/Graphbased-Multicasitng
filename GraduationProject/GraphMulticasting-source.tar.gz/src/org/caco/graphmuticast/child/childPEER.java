package org.caco.graphmuticast.child;

import java.io.IOException;

import org.greatfree.chat.ChatConfig;
import org.greatfree.data.ServerConfig;
import org.greatfree.dip.p2p.RegistryConfig;
import org.greatfree.dip.p2p.message.ChatRegistryRequest;
import org.greatfree.exceptions.RemoteReadException;
import org.greatfree.server.Peer;
import org.greatfree.util.TerminateSignal;

public class childPEER {
	private Peer<childPEERDispatcher> peer;

	private childPEER() {
	}



	private static childPEER instance = new childPEER();

	public static childPEER CHILD() {
		if (instance == null) {
			instance = new childPEER();
			return instance;
		} else {
			return instance;
		}
	}
	public String getChildIP()
	{
		return this.peer.getPeerIP();
	}

	/*
	 * Expose the child's port. i
	 */
	public int getChildPort()
	{
		return this.peer.getPort();
	}
	public void stop(long timeout)
			throws ClassNotFoundException, IOException, InterruptedException, RemoteReadException {
		this.peer.stop(timeout);
		childGraphMuticastor.CHILD().stop();
		TerminateSignal.SIGNAL().setTerminated();
	}

	public void start(String username) throws IOException, ClassNotFoundException, RemoteReadException, InterruptedException {
		this.peer = new Peer.PeerBuilder<childPEERDispatcher>().peerPort(ChatConfig.CHAT_SERVER_PORT).peerName(username)
				.registryServerIP(RegistryConfig.PEER_REGISTRY_ADDRESS)
				.registryServerPort(RegistryConfig.PEER_REGISTRY_PORT).isRegistryNeeded(true)
				.listenerCount(ServerConfig.LISTENING_THREAD_COUNT)
				.dispatcher(new childPEERDispatcher(RegistryConfig.DISPATCHER_THREAD_POOL_SIZE,
						RegistryConfig.DISPATCHER_THREAD_POOL_KEEP_ALIVE_TIME,
						RegistryConfig.SCHEDULER_THREAD_POOL_SIZE,
						RegistryConfig.SCHEDULER_THREAD_POOL_KEEP_ALIVE_TIME))
				.freeClientPoolSize(RegistryConfig.CLIENT_POOL_SIZE).readerClientSize(RegistryConfig.READER_CLIENT_SIZE)
				.syncEventerIdleCheckDelay(RegistryConfig.SYNC_EVENTER_IDLE_CHECK_DELAY)
				.syncEventerIdleCheckPeriod(RegistryConfig.SYNC_EVENTER_IDLE_CHECK_PERIOD)
				.syncEventerMaxIdleTime(RegistryConfig.SYNC_EVENTER_MAX_IDLE_TIME)
				.asyncEventQueueSize(RegistryConfig.ASYNC_EVENT_QUEUE_SIZE)
				.asyncEventerSize(RegistryConfig.ASYNC_EVENTER_SIZE)
				.asyncEventingWaitTime(RegistryConfig.ASYNC_EVENTING_WAIT_TIME)
				.asyncEventerWaitTime(RegistryConfig.ASYNC_EVENTER_WAIT_TIME)
				.asyncEventerWaitRound(RegistryConfig.ASYNC_EVENTER_WAIT_ROUND)
				.asyncEventIdleCheckDelay(RegistryConfig.ASYNC_EVENT_IDLE_CHECK_DELAY)
				.asyncEventIdleCheckPeriod(RegistryConfig.ASYNC_EVENT_IDLE_CHECK_PERIOD)
				.schedulerPoolSize(RegistryConfig.SCHEDULER_THREAD_POOL_SIZE)
				.schedulerKeepAliveTime(RegistryConfig.SCHEDULER_THREAD_POOL_KEEP_ALIVE_TIME).build();

		this.peer.start();
		this.peer.read(RegistryConfig.PEER_REGISTRY_ADDRESS, ChatConfig.CHAT_REGISTRY_PORT,
				new ChatRegistryRequest(this.peer.getPeerID()));
//必须作poll处理。
		childGraphMuticastor.CHILD().start(this.peer.getClientPool(),username);

	}


}
