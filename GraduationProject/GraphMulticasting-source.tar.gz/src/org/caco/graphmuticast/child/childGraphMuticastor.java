package org.caco.graphmuticast.child;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.caco.graphmuticast.message.ChildGottenMSTNotification;
import org.caco.graphmuticast.message.MST;
import org.caco.graphmuticast.message.MSTTreeRequest;
import org.caco.graphmuticast.message.MSTTreeResponse;
import org.greatfree.chat.ChatConfig;
import org.greatfree.client.FreeClientPool;
import org.greatfree.client.IPPort;
import org.greatfree.client.RemoteReader;
import org.greatfree.client.SyncRemoteEventer;
import org.greatfree.concurrency.Scheduler;
import org.greatfree.dip.multicast.message.PeerAddressRequest;
import org.greatfree.dip.multicast.message.PeerAddressResponse;
import org.greatfree.dip.p2p.RegistryConfig;
import org.greatfree.exceptions.RemoteReadException;
import org.greatfree.message.ServerMessage;
import org.greatfree.util.NodeID;
import org.greatfree.util.Tools;

public class childGraphMuticastor {
	private MST mstree;

	public MST getMstree() {
		return mstree;
	}

	public void setMstree(MST mstree) {
		this.mstree = mstree;
	}

	private String childName;
	private List<IPPort> childIpPorts;
	private SyncRemoteEventer<ServerMessage> eventer;

	private childGraphMuticastor() {
	}

	private static childGraphMuticastor instance = new childGraphMuticastor();

	public static childGraphMuticastor CHILD() {
		if (instance == null) {
			instance = new childGraphMuticastor();
			return instance;
		} else {
			return instance;
		}
	}

	public void start(FreeClientPool clientPool, String childName)
			throws ClassNotFoundException, RemoteReadException, IOException, InterruptedException {
		this.eventer = new SyncRemoteEventer<ServerMessage>(clientPool);
		this.childName = childName;
		PollMSTree();

	}

	public void broadcastNotify(ServerMessage notification)
			throws ClassNotFoundException, RemoteReadException, IOException, InterruptedException {
		if (this.mstree != null) {
			if (this.childIpPorts != null) {
				for (IPPort childiPort : this.childIpPorts) {
					this.eventer.notify(childiPort, notification);
				}
			} else {
				System.out.println("There have no child , Multicast END.");
			}
		} else {
			System.out.println("MST has not got from MSTserver");
		}
	}

	public ServerMessage read(String ip, int port, ServerMessage request)
			throws ClassNotFoundException, RemoteReadException, IOException {
		return RemoteReader.REMOTE().read(NodeID.DISTRIBUTED().getKey(), ip, port, request);
	}

	public MSTTreeResponse reqMST() throws ClassNotFoundException, RemoteReadException, IOException {
		return (MSTTreeResponse) this.read(ChatConfig.CHAT_SERVER_ADDRESS, ChatConfig.MST_SERVER_PORT,
				new MSTTreeRequest(this.childName));
	}

	public void PollMSTree() throws ClassNotFoundException, RemoteReadException, IOException, InterruptedException {
		Scheduler.GREATFREE().init(RegistryConfig.SCHEDULER_THREAD_POOL_SIZE,
				RegistryConfig.SCHEDULER_THREAD_POOL_KEEP_ALIVE_TIME);
		Scheduler.GREATFREE().submit(new PollingGetMST(), ChatConfig.CHAT_POLLING_DELAY,
				ChatConfig.CHILD_POLLING_PERIOD);

	}

	public void getchildIpPorts() throws ClassNotFoundException, RemoteReadException, IOException {
		this.childIpPorts = new ArrayList<IPPort>();
		IPPort childIP;
		if (this.mstree.getMSTtree().get(childName) != null) {
			System.out.println("\n--------------------------------------------");
			System.out.println("Current PeerName: " + this.childName);
			System.out.println("--------------------------------------------");
			System.out.println("Its childs IP&Ports:");
			for (String childName : this.mstree.getMSTtree().get(this.childName)) {
				PeerAddressResponse response = (PeerAddressResponse) this.read(RegistryConfig.PEER_REGISTRY_ADDRESS,
						RegistryConfig.PEER_REGISTRY_PORT, new PeerAddressRequest(Tools.getHash(childName)));
				childIP = new IPPort(response.getPeerAddress());
				this.childIpPorts.add(childIP);
				System.out.println(childName + " " + childIP);
			}
			System.out.println("--------------------------------------------\n");
			System.out.println("Child's IPPorts have been stored");
		} else {
			System.out.println("\n--------------------------------------------");
			System.out.println("Current PeerName: " + this.childName);
			System.out.println("--------------------------------------------");
			System.out.println("This child have No child left ");
			System.out.println("--------------------------------------------");
		}
	}

	public void sendGottenMSTNotification() throws IOException, InterruptedException {
		this.eventer.notify(ChatConfig.CHAT_SERVER_ADDRESS, ChatConfig.MST_SERVER_PORT,
				new ChildGottenMSTNotification(this.childName));
	}

	public void stop() throws IOException, InterruptedException {
		this.eventer.dispose();
	}
}
