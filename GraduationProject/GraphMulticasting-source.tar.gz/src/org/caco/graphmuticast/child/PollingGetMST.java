package org.caco.graphmuticast.child;

import java.io.IOException;

import org.caco.graphmuticast.message.MSTTreeResponse;
import org.caco.graphmuticast.message.MSTtools;
import org.greatfree.concurrency.Scheduler;
import org.greatfree.dip.p2p.RegistryConfig;
import org.greatfree.exceptions.RemoteReadException;
//Used in scheduler handler.Caco
public class PollingGetMST implements Runnable {

	@Override
	public void run() {
		
		try {
			boolean isGetMst;
			MSTTreeResponse resFromMstserver;	
			resFromMstserver = childGraphMuticastor.CHILD().reqMST();
			isGetMst = resFromMstserver.isRecived();
			if (isGetMst) {
				childGraphMuticastor.CHILD().setMstree(resFromMstserver.getMSTtree());
	//Notifying the MSTserver that this child has gotten MST.Caco
				childGraphMuticastor.CHILD().sendGottenMSTNotification();
				System.out.println("\n--------------------------------------------");
				System.out.println("Polling Res:");
				System.out.println("MST has been stored in this child");
				System.out.println("--------------------------------------------");
				MSTtools.printRootTree(resFromMstserver.getMSTtree().getMSTtree());
	//when get MST from server, it is necessary to get child's IPPort immediately.Caco
				childGraphMuticastor.CHILD().getchildIpPorts();
	//shutdown the scheduler
				Scheduler.GREATFREE().shutdown(RegistryConfig.SCHEDULER_SHUTDOWN_TIMEOUT);

			} else {
				System.out.println("\n--------------------------------------------");
				System.out.println("Polling Res:");
				System.out.println("Can't get MST from mstserver.RootPeer Not Ready");
				System.out.println("----------------------------------------------");
				
			}
		} catch (ClassNotFoundException | RemoteReadException | IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			System.out.println("=====Scheduler thread SHUTDOWN , Polling over=====");
			
		}
		
	}
}
