package org.caco.graphmuticast.client;

import java.io.IOException;
import java.util.Scanner;

import org.greatfree.chat.ChatOptions;
import org.greatfree.dip.old.multicast.root.MulticastOptions;
import org.greatfree.dip.old.multicast.root.MulticastRootMenu;
import org.greatfree.exceptions.RemoteReadException;
import org.greatfree.testing.client.ClientMenu;
import org.greatfree.testing.client.MenuOptions;

public class MulticastGraphClintUI {
	private Scanner in = new Scanner(System.in);

	private MulticastGraphClintUI() {
	}

	private static MulticastGraphClintUI instance = new MulticastGraphClintUI();

	public static MulticastGraphClintUI FRONT() {
		if (instance == null) {
			instance = new MulticastGraphClintUI();
			return instance;
		} else {
			return instance;
		}
	}

	public void dispose() {
		this.in.close();
	}

	/*
	 * Print the menu list on the screen.
	 */
	public void printMenu() {
		System.out.println(MulticastRootMenu.MENU_HEAD);
		System.out.println(MulticastRootMenu.BROADCAST_NOTIFICATION);
		System.out.println(MulticastRootMenu.QUIT);
		System.out.println(MulticastRootMenu.MENU_TAIL);
	}

	/*
	 * Send the users' option to the Root peer.
	 */
	public void send(int option) throws ClassNotFoundException, IOException, InstantiationException,
			IllegalAccessException, InterruptedException, RemoteReadException {
		switch (option) {
		case MulticastOptions.BROADCAST_NOTIFICATION:
			this.communicate(option);
			break;

		case MulticastOptions.QUIT:
			break;
		default:
			System.out.println("Wrong option");
		}
	}

	private void communicate(int highOption) throws InstantiationException, IllegalAccessException, IOException,
			InterruptedException, ClassNotFoundException, RemoteReadException {
		int notificationOption = ChatOptions.NO_OPTION;
		String optionStr;
		while (notificationOption != MulticastOptions.QUIT) {
			MulticastGraphClintInputUI.CLUSTER().printMenu();
			optionStr = in.nextLine();
			try {
				notificationOption = Integer.parseInt(optionStr);
				System.out.println("Your choice: " + highOption);
				MulticastGraphClintInputUI.CLUSTER().send(highOption, notificationOption);
			} catch (NumberFormatException e) {
				notificationOption = MenuOptions.NO_OPTION;
				System.out.println(ClientMenu.WRONG_OPTION);
			}
		}
	}
}
