package org.caco.graphmuticast.client;

import java.io.IOException;
import java.util.Scanner;

import org.greatfree.chat.MenuOptions;
import org.greatfree.exceptions.RemoteReadException;
import org.greatfree.testing.client.ClientMenu;

public class startClient {
	public static void main(String[] args) throws IOException, InterruptedException {
		int option = MenuOptions.NO_OPTION;

		// Initialize a command input console for users to interact with the system.
		Scanner in = new Scanner(System.in);
		String optionStr;

		System.out.println("Multicast client starting up ...");
		try {
			MulticastNotiyClient.FRONT().init();
		} catch (ClassNotFoundException | RemoteReadException | IOException e) {
			e.printStackTrace();
		}
		System.out.println("Multicast client started ...");
		while (option != MenuOptions.QUIT) {
			MulticastGraphClintUI.FRONT().printMenu();
			// Input a string that represents users' intents.
			optionStr = in.nextLine();
			// Convert the input string to integer.
			option = Integer.parseInt(optionStr);
			System.out.println("Your choice: " + option);
			try {
				MulticastGraphClintUI.FRONT().send(option);
			} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | IOException
					| InterruptedException | RemoteReadException e) {
				option = MenuOptions.NO_OPTION;
				System.out.println(ClientMenu.WRONG_OPTION);
			}

		}
//shutdown the cluster
		MulticastNotiyClient.FRONT().shutdownClusterNotify();
	
		MulticastNotiyClient.FRONT().dispose();
		in.close();
	}

}
