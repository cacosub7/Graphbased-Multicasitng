package org.caco.graphmuticast.client;

import java.io.IOException;
import java.util.Scanner;

import org.caco.graphmuticast.message.HelloWorldBroadCastNotificaiton;
import org.greatfree.chat.ChatMenu;
import org.greatfree.chat.ChatOptions;
import org.greatfree.dip.multicast.HelloWorld;
import org.greatfree.dip.old.multicast.root.MulticastOptions;
import org.greatfree.exceptions.RemoteReadException;

public class MulticastGraphClintInputUI {

	private Scanner in = new Scanner(System.in);

	private MulticastGraphClintInputUI() {
	}

	/*
	 * Initialize a singleton. 04/23/2017, Bing Li
	 */
	private static MulticastGraphClintInputUI instance = new MulticastGraphClintInputUI();

	public static MulticastGraphClintInputUI CLUSTER() {
		if (instance == null) {
			instance = new MulticastGraphClintInputUI();
			return instance;
		} else {
			return instance;
		}
	}

	public void dispose() {
		this.in.close();
	}

	/*
	 * Print the menu list on the screen.
	 */
	public void printMenu() {
		System.out.println(ChatMenu.MENU_HEAD);
		System.out.println(ChatMenu.TYPE_MESSAGE);
		System.out.println(ChatMenu.QUIT);
		System.out.println(ChatMenu.MENU_TAIL);
		System.out.println(ChatMenu.INPUT_PROMPT);
	}

	public void send(int highOption, int option) throws InstantiationException, IllegalAccessException, IOException,
			InterruptedException, ClassNotFoundException, RemoteReadException {
		switch (option) {
		case ChatOptions.TYPE_CHAT:
			System.out.println("Please type your message: ");
			String message = in.nextLine();
			switch (highOption) {
			case MulticastOptions.BROADCAST_NOTIFICATION:
				MulticastNotiyClient.FRONT().syncNotify(new HelloWorldBroadCastNotificaiton(new HelloWorld(message)));
				System.out.println("You notification is broadcast!");
				break;

			}
			break;

		case ChatOptions.QUIT_CHAT:
			break;
		}
	}
}
