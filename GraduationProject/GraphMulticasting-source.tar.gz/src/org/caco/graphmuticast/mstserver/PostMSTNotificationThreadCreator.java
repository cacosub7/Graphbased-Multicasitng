package org.caco.graphmuticast.mstserver;

import org.caco.graphmuticast.message.PostMSTNotification;
import org.greatfree.concurrency.interactive.NotificationThreadCreatable;

public class PostMSTNotificationThreadCreator implements NotificationThreadCreatable<PostMSTNotification, PostMSTNotificationThread>{

	@Override
	public PostMSTNotificationThread createNotificationThreadInstance(int taskSize) {
		return new PostMSTNotificationThread(taskSize);
	}

}
