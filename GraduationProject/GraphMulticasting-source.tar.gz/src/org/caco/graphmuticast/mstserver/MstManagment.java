package org.caco.graphmuticast.mstserver;

import java.util.Vector;

import org.caco.graphmuticast.message.MST;
import org.caco.graphmuticast.message.MSTtools;

public class MstManagment {
	private MST mst;
//Is Recvied MST from root
	private boolean isRecvied;
//Is All childs get MST 
	private boolean isChildsReady;
//For concurrent sake, we choose Vector to operate
	private Vector<String> readyChilds;
//the number of childs in this Multicast System
	private int ChildsNumber;

	public int getChildsNumber() {
		return ChildsNumber;
	}

	public void setChildsNumber(int childsNumber) {
		ChildsNumber = childsNumber;
	}

	public boolean isChildsReady() {
		if (this.readyChilds != null) {
			if (this.readyChilds.size() >= this.ChildsNumber) {
				this.isChildsReady = true;
			}
		}
		return isChildsReady;
	}

	public void setChildsReady(boolean isChildsReady) {
		this.isChildsReady = isChildsReady;
	}

	public MST getMst() {
		return mst;
	}

	public void setMst(MST mst) {
		this.mst = mst;
		this.isRecvied = true;
	}

	public void printMST() {
		MSTtools.PrintMatrix(mst.getMatrix());
		MSTtools.printRootTree(mst.getMSTtree());
	}

	public boolean isRecvied() {
		return isRecvied;
	}

	public Vector<String> getReadyChilds() {
		return readyChilds;
	}

	public void setReadyChilds(Vector<String> readyChilds) {
		this.readyChilds = readyChilds;
	}

	public void setRecvied(boolean isRecvied) {
		this.isRecvied = isRecvied;
	}

	public void addChildToReadyVector(String childname) {
		if (!this.isChildsReady) {
			if (!readyChilds.contains(childname)) {
				readyChilds.add(childname);
			}
		}
	}

	private MstManagment() {
		this.isRecvied = false;
		this.readyChilds = new Vector<String>();
	}

	private static MstManagment instance = new MstManagment();

	public static MstManagment MM() {
		if (instance == null) {
			instance = new MstManagment();
			return instance;
		} else {
			return instance;
		}
	}

}
