package org.caco.graphmuticast.mstserver;
import java.io.IOException;

//Created by Caco .5.20
import org.caco.graphmuticast.message.ShutdownMSTserverNotification;
import org.greatfree.concurrency.interactive.NotificationQueue;
import org.greatfree.data.ServerConfig;
import org.greatfree.exceptions.RemoteReadException;

public class ShutdownMSTserverNotificationThread extends NotificationQueue<ShutdownMSTserverNotification>{

	public ShutdownMSTserverNotificationThread(int taskSize) {
		super(taskSize);
	}

	public void run() {
		ShutdownMSTserverNotification notification;
		while (!this.isShutdown())
		{
			while (!this.isEmpty())
			{
				try
				{
					notification = this.getNotification();
					Mstserver.CS().stop(ServerConfig.SERVER_SHUTDOWN_TIMEOUT);
					this.disposeMessage(notification);
				}
				catch (InterruptedException | ClassNotFoundException | IOException | RemoteReadException e)
				{
					e.printStackTrace();
				}
			}
			try
			{
				// Wait for a moment after all of the existing notifications are processed.
				this.holdOn(ServerConfig.NOTIFICATION_THREAD_WAIT_TIME);
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}

}
