package org.caco.graphmuticast.mstserver;
//Created by Caco. 5.20
import org.caco.graphmuticast.message.ShutdownMSTserverNotification;
import org.greatfree.concurrency.interactive.NotificationThreadCreatable;

public class ShutdownMSTserverNotificationThreadCreator implements NotificationThreadCreatable<ShutdownMSTserverNotification,ShutdownMSTserverNotificationThread>{

	@Override
	public ShutdownMSTserverNotificationThread createNotificationThreadInstance(int taskSize) {
		return new ShutdownMSTserverNotificationThread(taskSize);
	}

}
