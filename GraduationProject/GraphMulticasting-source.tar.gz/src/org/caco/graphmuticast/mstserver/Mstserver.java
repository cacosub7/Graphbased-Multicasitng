package org.caco.graphmuticast.mstserver;
//CREATED BY CACO 4.26

import java.io.IOException;

import org.greatfree.chat.ChatConfig;
import org.greatfree.data.ServerConfig;
import org.greatfree.dip.p2p.RegistryConfig;
import org.greatfree.exceptions.RemoteReadException;
import org.greatfree.server.CSServer;
import org.greatfree.util.TerminateSignal;

public class Mstserver {
	private CSServer<MSTDispatcher> server;
	private CSServer<ManMSTDispatcher> manServer;
	private Mstserver() {
	}

	private static Mstserver instance = new Mstserver();

	public static Mstserver CS() {
		if (instance == null) {
			instance = new Mstserver();
			return instance;
		} else {
			return instance;
		}
	}

	public void stop(long timeout)
			throws IOException, InterruptedException, ClassNotFoundException, RemoteReadException {
		TerminateSignal.SIGNAL().setTerminated();
		this.server.stop(timeout);
		this.manServer.stop(timeout);
	}

	public void start() throws IOException, ClassNotFoundException, RemoteReadException {
		this.server = new CSServer.CSServerBuilder<MSTDispatcher>().port(ChatConfig.MST_SERVER_PORT)
				.listenerCount(ServerConfig.LISTENING_THREAD_COUNT)
				.dispatcher(new MSTDispatcher(RegistryConfig.DISPATCHER_THREAD_POOL_SIZE,
						RegistryConfig.DISPATCHER_THREAD_POOL_KEEP_ALIVE_TIME,
						RegistryConfig.SCHEDULER_THREAD_POOL_SIZE,
						RegistryConfig.SCHEDULER_THREAD_POOL_KEEP_ALIVE_TIME))
				.build();

		// Initialize the chat management server.

		// Start up the two servers. 
		this.server.start();
		this.manServer = new CSServer.CSServerBuilder<ManMSTDispatcher>()
				.port(ChatConfig.MST_SERVER_SHTDOWN_PORT)
				.listenerCount(ServerConfig.LISTENING_THREAD_COUNT)
				.dispatcher(new ManMSTDispatcher(RegistryConfig.DISPATCHER_THREAD_POOL_SIZE, RegistryConfig.DISPATCHER_THREAD_POOL_KEEP_ALIVE_TIME, RegistryConfig.SCHEDULER_THREAD_POOL_SIZE, RegistryConfig.SCHEDULER_THREAD_POOL_KEEP_ALIVE_TIME))
				.build();
		
		this.manServer.start();
	
	}

}
