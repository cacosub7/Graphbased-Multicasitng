package org.caco.graphmuticast.mstserver;

import java.io.IOException;
import org.caco.graphmuticast.message.MST;
import org.caco.graphmuticast.message.MSTTreeRequest;
import org.caco.graphmuticast.message.MSTTreeRequestStream;
import org.caco.graphmuticast.message.MSTTreeResponse;
import org.greatfree.concurrency.interactive.RequestQueue;
import org.greatfree.data.ServerConfig;

//CREATED BY CACO 4.26
public class MSTTreeRequestThread extends RequestQueue<MSTTreeRequest, MSTTreeRequestStream, MSTTreeResponse> {

	public MSTTreeRequestThread(int notificationQueueSize) {
		super(notificationQueueSize);
	}

	@Override
	public void run() {
		MSTTreeRequestStream request;
		MSTTreeResponse response;
		String childName;

		while (!this.isShutdown()) {
			while (!this.isEmpty()) {
				request = this.getRequest();
				childName = request.getMessage().getChildName();
				System.out.println("MSTrequestGet ,child's name : " + childName);
				if (MstManagment.MM().isRecvied()) {					
//To lower cost, constructing a MST without Matrix for child.Caco
					MST mstForChild = new MST(MstManagment.MM().getMst().getMSTtree());
					response = new MSTTreeResponse(mstForChild);
				} else {
					response = new MSTTreeResponse(false);

				}
				try {
					this.respond(request.getOutStream(), request.getLock(), response);
				} catch (IOException e) {
					e.printStackTrace();
				}
				this.disposeMessage(request, response);
				try {
					// Wait for some time when the queue is empty. During the period and before the
					// thread is killed, some new requests might be received. If so, the thread can
					// keep working. 02/15/2016, Bing Li
					this.holdOn(ServerConfig.REQUEST_THREAD_WAIT_TIME);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

	}

};