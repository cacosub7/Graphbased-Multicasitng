package org.caco.graphmuticast.mstserver;

//Created by caco 5.15
import org.caco.graphmuticast.message.ChildGottenMSTNotification;
import org.greatfree.concurrency.interactive.NotificationQueue;
import org.greatfree.data.ServerConfig;

public class ChildGottenMSTNotificationThread extends NotificationQueue<ChildGottenMSTNotification> {

	public ChildGottenMSTNotificationThread(int taskSize) {
		super(taskSize);
	}

	@Override
	public void run() {
		ChildGottenMSTNotification notification;
		while (!this.isShutdown()) {
			while (!this.isEmpty()) {
				try {
					notification = this.getNotification();
					String childname = notification.getChildname();
					MstManagment.MM().addChildToReadyVector(childname);
					System.out.println("-------------------------------------------------");
					System.out.println(childname + " has gotten the MST");
					System.out.println("-------------------------------------------------");
					this.dispose(notification);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					this.holdOn(ServerConfig.NOTIFICATION_THREAD_WAIT_TIME);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

	}

}
