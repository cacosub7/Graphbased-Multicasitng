package org.caco.graphmuticast.mstserver;
//Created by Caco. 5.15
import org.caco.graphmuticast.message.ChildGottenMSTNotification;
import org.greatfree.concurrency.interactive.NotificationThreadCreatable;

public class ChildGottenMSTNotificationThreadCreator implements NotificationThreadCreatable<ChildGottenMSTNotification, ChildGottenMSTNotificationThread>{

	@Override
	public ChildGottenMSTNotificationThread createNotificationThreadInstance(int taskSize) {
		return new ChildGottenMSTNotificationThread(taskSize);
	}

}
