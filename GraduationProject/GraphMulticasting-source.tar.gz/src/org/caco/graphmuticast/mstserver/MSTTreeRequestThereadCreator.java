package org.caco.graphmuticast.mstserver;

import org.caco.graphmuticast.message.MSTTreeRequest;
import org.caco.graphmuticast.message.MSTTreeRequestStream;
import org.caco.graphmuticast.message.MSTTreeResponse;
import org.greatfree.concurrency.interactive.RequestThreadCreatable;

//CREATED BY CACO 4.26
public class MSTTreeRequestThereadCreator implements RequestThreadCreatable<MSTTreeRequest, MSTTreeRequestStream, MSTTreeResponse, MSTTreeRequestThread>{

	@Override
	public MSTTreeRequestThread createRequestThreadInstance(int taskSize) {
		return new MSTTreeRequestThread(taskSize);
	}

}
