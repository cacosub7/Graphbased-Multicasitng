package org.caco.graphmuticast.mstserver;

import java.io.IOException;

import org.greatfree.data.ServerConfig;
import org.greatfree.exceptions.RemoteReadException;
import org.greatfree.util.TerminateSignal;

public class startmstserver {
	public static void main(String[] args) throws ClassNotFoundException, IOException, RemoteReadException, InterruptedException {
		System.out.println("Mstserver Starting up..");
		Mstserver.CS().start();
		System.out.println("Mstserver started");
		
		while(!TerminateSignal.SIGNAL().isTerminated()) {
			Thread.sleep(ServerConfig.TERMINATE_SLEEP);
		}
	}
}
