package org.caco.graphmuticast.mstserver;

import org.caco.graphmuticast.message.PostMSTNotification;
import org.greatfree.concurrency.interactive.NotificationQueue;
import org.greatfree.data.ServerConfig;

public class PostMSTNotificationThread extends NotificationQueue<PostMSTNotification> {

	public PostMSTNotificationThread(int taskSize) {
		super(taskSize);
	}

	@Override
	public void run() {
		PostMSTNotification notification;
		while (!this.isShutdown()) {
			while (!this.isEmpty()) {
				try {
					notification = this.getNotification();
					int childsNumber = notification.getmST().GetNodeCount();
					System.out.println("\n--------------------------------------------");
					System.out.println("get MST,there have " + childsNumber + " peers in tree");
//substract root
					MstManagment.MM().setChildsNumber(childsNumber - 1);
					MstManagment.MM().setMst(notification.getmST());
					MstManagment.MM().printMST();
					System.out.println(" MST stored.");
					System.out.println("--------------------------------------------");
					this.dispose(notification);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				try {
					this.holdOn(ServerConfig.NOTIFICATION_THREAD_WAIT_TIME);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}
		}
	}

}
