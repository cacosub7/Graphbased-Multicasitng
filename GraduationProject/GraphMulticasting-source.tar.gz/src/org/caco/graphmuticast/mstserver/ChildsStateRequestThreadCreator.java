package org.caco.graphmuticast.mstserver;

import org.caco.graphmuticast.message.ChildsStateRequest;
import org.caco.graphmuticast.message.ChildsStateRequestStream;
import org.caco.graphmuticast.message.ChildsStateResponse;
import org.greatfree.concurrency.interactive.RequestThreadCreatable;

public class ChildsStateRequestThreadCreator implements RequestThreadCreatable<ChildsStateRequest,ChildsStateRequestStream,ChildsStateResponse,ChildsStateRequestThread>{

	@Override
	public ChildsStateRequestThread createRequestThreadInstance(int taskSize) {
		// TODO Auto-generated method stub
		return new ChildsStateRequestThread(taskSize);
	}

}
