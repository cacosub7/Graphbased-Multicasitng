package org.caco.graphmuticast.mstserver;

import java.io.IOException;

import org.caco.graphmuticast.message.ChildsStateRequest;
import org.caco.graphmuticast.message.ChildsStateRequestStream;
import org.caco.graphmuticast.message.ChildsStateResponse;
import org.greatfree.concurrency.interactive.RequestQueue;
import org.greatfree.data.ServerConfig;

public class ChildsStateRequestThread
		extends RequestQueue<ChildsStateRequest, ChildsStateRequestStream, ChildsStateResponse> {

	public ChildsStateRequestThread(int notificationQueueSize) {
		super(notificationQueueSize);
	}

	@Override
	public void run() {
		ChildsStateRequestStream request;
		ChildsStateResponse response;
		while (!this.isShutdown()) {
			while (!this.isEmpty()) {
				request = this.getRequest();
				boolean isChildsReady = MstManagment.MM().isChildsReady();
				if (isChildsReady) {
					System.out.println("-------------------------------------------------");
					System.out.println("Childs state : All childs get MST!");
					System.out.println("-------------------------------------------------");
					response = new ChildsStateResponse(isChildsReady);
				} else {
					System.out.println("-------------------------------------------------");
					System.out.println("Childs state : Some of them have not got MST yet!");
					System.out.println("-------------------------------------------------");
					response = new ChildsStateResponse(false);
				}
				try {
					this.respond(request.getOutStream(), request.getLock(), response);
				} catch (IOException e) {
					e.printStackTrace();
				}
				this.disposeMessage(request, response);
				try {
					this.holdOn(ServerConfig.REQUEST_THREAD_WAIT_TIME);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
