package org.caco.graphmuticast.mstserver;

import java.util.Calendar;

import org.caco.graphmuticast.message.ChildsStateRequest;
import org.caco.graphmuticast.message.ChildsStateRequestStream;
import org.caco.graphmuticast.message.ChildsStateResponse;
import org.caco.graphmuticast.message.MSTTreeRequest;
import org.caco.graphmuticast.message.MSTTreeRequestStream;
import org.caco.graphmuticast.message.MSTTreeResponse;
import org.caco.graphmuticast.message.MuticastMessageType;
import org.caco.graphmuticast.message.PostMSTNotification;
import org.caco.graphmuticast.message.ChildGottenMSTNotification;
import org.greatfree.client.OutMessageStream;
import org.greatfree.concurrency.interactive.NotificationDispatcher;
import org.greatfree.concurrency.interactive.RequestDispatcher;
import org.greatfree.data.ServerConfig;
import org.greatfree.message.ServerMessage;
import org.greatfree.server.ServerDispatcher;

//CREATED BY CACO 4.26
public class MSTDispatcher extends ServerDispatcher<ServerMessage> {

	private NotificationDispatcher<PostMSTNotification, PostMSTNotificationThread, PostMSTNotificationThreadCreator> rootMSTNotificationDispatcher;
	private RequestDispatcher<MSTTreeRequest, MSTTreeRequestStream, MSTTreeResponse, MSTTreeRequestThread, MSTTreeRequestThereadCreator> childRequestDispatcher;
	private RequestDispatcher<ChildsStateRequest,ChildsStateRequestStream,ChildsStateResponse,ChildsStateRequestThread,ChildsStateRequestThreadCreator> childsStateRequestDispatcher;
	private NotificationDispatcher<ChildGottenMSTNotification, ChildGottenMSTNotificationThread, ChildGottenMSTNotificationThreadCreator> childGottenMSTNotificationDispatcher;

	public MSTDispatcher(int serverThreadPoolSize, long serverThreadKeepAliveTime, int schedulerPoolSize,
			long schedulerKeepAliveTime) {
		super(serverThreadPoolSize, serverThreadKeepAliveTime, schedulerPoolSize, schedulerKeepAliveTime);
		this.rootMSTNotificationDispatcher = new NotificationDispatcher.NotificationDispatcherBuilder<PostMSTNotification, PostMSTNotificationThread, PostMSTNotificationThreadCreator>()
				.poolSize(ServerConfig.NOTIFICATION_DISPATCHER_POOL_SIZE)
				.threadCreator(new PostMSTNotificationThreadCreator())
				.notificationQueueSize(ServerConfig.NOTIFICATION_QUEUE_SIZE)
				.dispatcherWaitTime(ServerConfig.NOTIFICATION_DISPATCHER_WAIT_TIME)
				.waitRound(ServerConfig.NOTIFICATION_DISPATCHER_WAIT_ROUND)
				.idleCheckDelay(ServerConfig.NOTIFICATION_DISPATCHER_IDLE_CHECK_DELAY)
				.idleCheckPeriod(ServerConfig.NOTIFICATION_DISPATCHER_IDLE_CHECK_PERIOD).scheduler(super.getScheduler())
				.build();
		this.childGottenMSTNotificationDispatcher = new NotificationDispatcher.NotificationDispatcherBuilder<ChildGottenMSTNotification, ChildGottenMSTNotificationThread, ChildGottenMSTNotificationThreadCreator>()
				.poolSize(ServerConfig.NOTIFICATION_DISPATCHER_POOL_SIZE)
				.threadCreator(new ChildGottenMSTNotificationThreadCreator())
				.notificationQueueSize(ServerConfig.NOTIFICATION_QUEUE_SIZE)
				.dispatcherWaitTime(ServerConfig.NOTIFICATION_DISPATCHER_WAIT_TIME)
				.waitRound(ServerConfig.NOTIFICATION_DISPATCHER_WAIT_ROUND)
				.idleCheckDelay(ServerConfig.NOTIFICATION_DISPATCHER_IDLE_CHECK_DELAY)
				.idleCheckPeriod(ServerConfig.NOTIFICATION_DISPATCHER_IDLE_CHECK_PERIOD).scheduler(super.getScheduler())
				.build();
		this.childRequestDispatcher = new RequestDispatcher.RequestDispatcherBuilder<MSTTreeRequest, MSTTreeRequestStream, MSTTreeResponse, MSTTreeRequestThread, MSTTreeRequestThereadCreator>()
				.poolSize(ServerConfig.REQUEST_DISPATCHER_POOL_SIZE).threadCreator(new MSTTreeRequestThereadCreator())
				.requestQueueSize(ServerConfig.REQUEST_QUEUE_SIZE)
				.dispatcherWaitTime(ServerConfig.REQUEST_DISPATCHER_WAIT_TIME)
				.waitRound(ServerConfig.REQUEST_DISPATCHER_WAIT_ROUND)
				.idleCheckDelay(ServerConfig.REQUEST_DISPATCHER_IDLE_CHECK_DELAY)
				.idleCheckPeriod(ServerConfig.REQUEST_DISPATCHER_IDLE_CHECK_PERIOD).scheduler(super.getScheduler())
				.build();
		this.childsStateRequestDispatcher = new RequestDispatcher.RequestDispatcherBuilder<ChildsStateRequest,ChildsStateRequestStream,ChildsStateResponse,ChildsStateRequestThread,ChildsStateRequestThreadCreator>()
				.poolSize(ServerConfig.REQUEST_DISPATCHER_POOL_SIZE).threadCreator(new ChildsStateRequestThreadCreator())
				.requestQueueSize(ServerConfig.REQUEST_QUEUE_SIZE)
				.dispatcherWaitTime(ServerConfig.REQUEST_DISPATCHER_WAIT_TIME)
				.waitRound(ServerConfig.REQUEST_DISPATCHER_WAIT_ROUND)
				.idleCheckDelay(ServerConfig.REQUEST_DISPATCHER_IDLE_CHECK_DELAY)
				.idleCheckPeriod(ServerConfig.REQUEST_DISPATCHER_IDLE_CHECK_PERIOD).scheduler(super.getScheduler())
				.build();
	}

	@Override
	public void dispose(long timeout) throws InterruptedException {
		this.childRequestDispatcher.dispose();
		this.childGottenMSTNotificationDispatcher.dispose();
		this.rootMSTNotificationDispatcher.dispose();
		this.childRequestDispatcher.dispose();
		super.shutdown(timeout);
	}

	@Override
	public void process(OutMessageStream<ServerMessage> message) {
		switch (message.getMessage().getType()) {
		case MuticastMessageType.POSTMST_NOTIFICATION:
			System.out.println("MST from RootNode notification recived.@" + Calendar.getInstance().getTime());
			if (!this.rootMSTNotificationDispatcher.isReady()) {
				super.execute(this.rootMSTNotificationDispatcher);
			}
			this.rootMSTNotificationDispatcher.enqueue((PostMSTNotification) message.getMessage());
			break;
		case MuticastMessageType.CHILD_GOTTEN_MST_NOTIFIATION:
			System.out.println("Child gotten MST  notificaiton recived.@" + Calendar.getInstance().getTime());
			if (!this.childGottenMSTNotificationDispatcher.isReady()) {
				super.execute(this.childGottenMSTNotificationDispatcher);
			}
			this.childGottenMSTNotificationDispatcher.enqueue((ChildGottenMSTNotification) message.getMessage());
			break;
		case MuticastMessageType.MSTTREE_REQUEST:
			System.out.println("MST from ChildNode Request recived.@" + Calendar.getInstance().getTime());
			if (!this.childRequestDispatcher.isReady()) {
				super.execute(this.childRequestDispatcher);
			}
			this.childRequestDispatcher.enqueue(new MSTTreeRequestStream(message.getOutStream(), message.getLock(),
					(MSTTreeRequest) message.getMessage()));
			break;
		case MuticastMessageType.CHILDS_STATE_REQUEST:
			System.out.println("Root childs state Request recived.@" + Calendar.getInstance().getTime());
			if (!this.childsStateRequestDispatcher.isReady()) {
				super.execute(this.childsStateRequestDispatcher);
			}
			this.childsStateRequestDispatcher.enqueue(new ChildsStateRequestStream(message.getOutStream(), message.getLock(),
					(ChildsStateRequest) message.getMessage()));
			break;

		}
	}
}
