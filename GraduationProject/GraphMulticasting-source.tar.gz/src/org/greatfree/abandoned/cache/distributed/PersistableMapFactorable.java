package org.greatfree.abandoned.cache.distributed;

public interface PersistableMapFactorable
{

}
