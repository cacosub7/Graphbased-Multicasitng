package org.greatfree.abandoned.cache.distributed;

// Created: 07/04/2017, Bing LI
public interface MapObjectReceivable
{
	public void valueReceived(Object obj);
}
