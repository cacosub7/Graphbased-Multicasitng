package org.greatfree.abandoned.cache.distributed;

// Created: 07/16/2017, Bing Li
public interface CacheKeyable
{
	public String getDataKey();
//	public void setDataKey(String dataKey);
	public String getCacheKey();
//	public void setCacheKey(String cacheKey);
}
