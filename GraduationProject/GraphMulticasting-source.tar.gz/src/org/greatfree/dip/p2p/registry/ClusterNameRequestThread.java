package org.greatfree.dip.p2p.registry;

import java.io.IOException;

import org.greatfree.concurrency.interactive.RequestQueue;
import org.greatfree.data.ServerConfig;
import org.greatfree.message.multicast.ClusterNameRequest;
import org.greatfree.message.multicast.ClusterNameResponse;
import org.greatfree.message.multicast.ClusterNameStream;
import org.greatfree.server.PeerRegistry;

/*
 * The thread retrieves all of the registered name of the distributed nodes within one cluster.CAco 
 */

public class ClusterNameRequestThread extends RequestQueue<ClusterNameRequest, ClusterNameStream, ClusterNameResponse>
{

	public ClusterNameRequestThread(int maxTaskSize)
	{
		super(maxTaskSize);
	}

	@Override
	public void run()
	{
		ClusterNameStream request;
		ClusterNameResponse response;
		while (!this.isShutdown())
		{
			while (!this.isEmpty())
			{
				request = this.getRequest();
				
				response = new ClusterNameResponse(AccountRegistry.APPLICATION().getPeersName(PeerRegistry.SYSTEM().getPeersName()));
				try
				{
					this.respond(request.getOutStream(), request.getLock(), response);
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
				this.disposeMessage(request, response);
			}
			try
			{
				// Wait for some time when the queue is empty. During the period and before the thread is killed, some new requests might be received. If so, the thread can keep working. 02/15/2016, Bing Li
				this.holdOn(ServerConfig.REQUEST_THREAD_WAIT_TIME);
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		
	}

}
