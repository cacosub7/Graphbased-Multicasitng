package org.greatfree.dip.p2p.registry;

import org.greatfree.concurrency.interactive.RequestThreadCreatable;
import org.greatfree.message.multicast.ClusterNameRequest;
import org.greatfree.message.multicast.ClusterNameResponse;
import org.greatfree.message.multicast.ClusterNameStream;



// Created by Caco
public class ClusterNameRequestThreadCreator implements RequestThreadCreatable<ClusterNameRequest, ClusterNameStream, ClusterNameResponse, ClusterNameRequestThread>
{

	@Override
	public ClusterNameRequestThread createRequestThreadInstance(int taskSize)
	{
		return new ClusterNameRequestThread(taskSize);
	}

}
