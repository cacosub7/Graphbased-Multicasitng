package org.greatfree.dip.multicast.root;

import org.greatfree.concurrency.interactive.NotificationThreadCreatable;
import org.greatfree.dip.multicast.message.HelloWorldBroadcastResponse;

// Created: 08/26/2018, Bing Li
public class HelloWorldBroadcastResponseThreadCreator implements NotificationThreadCreatable<HelloWorldBroadcastResponse, HelloWorldBroadcastResponseThread>
{

	@Override
	public HelloWorldBroadcastResponseThread createNotificationThreadInstance(int taskSize)
	{
		return new HelloWorldBroadcastResponseThread(taskSize);
	}

}
