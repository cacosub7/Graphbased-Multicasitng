package org.greatfree.dip.multicast.child;

import org.greatfree.concurrency.interactive.NotificationThreadCreatable;
import org.greatfree.dip.multicast.message.HelloWorldAnycastRequest;

// Created: 08/26/2018, Bing Li
public class HelloWorldAnycastRequestThreadCreator implements NotificationThreadCreatable<HelloWorldAnycastRequest, HelloWorldAnycastRequestThread>
{

	@Override
	public HelloWorldAnycastRequestThread createNotificationThreadInstance(int taskSize)
	{
		return new HelloWorldAnycastRequestThread(taskSize);
	}

}
