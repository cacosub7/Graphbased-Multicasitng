package org.greatfree.dip.multicast.rp.child;

import org.greatfree.concurrency.interactive.NotificationThreadCreatable;
import org.greatfree.dip.multicast.message.HelloWorldAnycastNotification;

// Created: 10/22/2018, Bing Li
public class HelloWorldAnycastNotificationThreadCreator implements NotificationThreadCreatable<HelloWorldAnycastNotification, HelloWorldAnycastNotificationThread>
{

	@Override
	public HelloWorldAnycastNotificationThread createNotificationThreadInstance(int taskSize)
	{
		return new HelloWorldAnycastNotificationThread(taskSize);
	}

}
