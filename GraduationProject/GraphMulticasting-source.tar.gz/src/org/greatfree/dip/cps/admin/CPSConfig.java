package org.greatfree.dip.cps.admin;

// Created: 07/08/2018, Bing Li
public class CPSConfig
{
	public final static int STOP_COORDINATOR = 1;
	public final static int STOP_TERMINAL = 2;
}
