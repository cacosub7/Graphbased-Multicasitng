package org.greatfree.dip.cps.cache.message.postfetch;

import java.util.Set;

import org.greatfree.cache.distributed.MapPostfetchNotification;
import org.greatfree.util.UtilConfig;

// Created: 08/25/2018, Bing Li
public class PostfetchMyStoreDataNotification extends MapPostfetchNotification
{
	public PostfetchMyStoreDataNotification(String mapKey, String resourceKey)
	{
		super(mapKey, resourceKey);
	}

	public PostfetchMyStoreDataNotification(String mapKey, Set<String> resourceKeys)
	{
		super(mapKey, resourceKeys);
	}
	
	public PostfetchMyStoreDataNotification(String mapKey)
	{
		super(mapKey, UtilConfig.NO_KEY);
	}

}
