package org.greatfree.server.container;

// Created: 12/18/2018, Bing Li
public class CSMessageType
{
	public final static int NOTIFICATION = 30;
	public final static int REQUEST = 31;

}
