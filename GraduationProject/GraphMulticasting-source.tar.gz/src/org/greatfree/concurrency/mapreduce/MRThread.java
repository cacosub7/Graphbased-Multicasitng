package org.greatfree.concurrency.mapreduce;

import org.greatfree.data.ServerConfig;

// Created: 01/27/2019, Bing Li
class MRThread extends MapReduceQueue<Sequence, Sequence, MRThread, MRThreadCreator>
{
	public MRThread(int taskSize, MRCore<Sequence, Sequence, MRThread, MRThreadCreator> mp)
	{
		super(taskSize, mp);
	}

	@Override
	public void run()
	{
		while (!this.isShutdown())
		{
			while (!this.isEmpty())
			{
				try
				{
					this.reduce(MRServiceProvider.MR().map(this.getTask()));
				}
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
			}
			try
			{
				this.holdOn(ServerConfig.NOTIFICATION_THREAD_WAIT_TIME);
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		
	}

}
